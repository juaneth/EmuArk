﻿using System.Windows.Forms;

namespace EmuArk_0._0._1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
    }
}
