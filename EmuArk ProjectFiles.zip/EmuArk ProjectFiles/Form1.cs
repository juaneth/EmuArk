﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmuArk_0._0._1
{
    public partial class Form1 : Form
    {
        private const string Path = "C:/Program Files (x86)/PCSX2/pcsx2.exe";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://dolphin-emu.org/download/");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.epsxe.com/download.php");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string pcsx2 = @"C:\Program Files (x86)\EmuArk\0.0.5 - Alpha\Emulators\pcsx2-1.6.0-setup.exe";
            Process.Start(pcsx2);
        }
    }
}
