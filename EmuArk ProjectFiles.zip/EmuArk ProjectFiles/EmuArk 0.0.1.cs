﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace EmuArk_0._0._1
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var newForm = new Form2();
            newForm.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string Dolphin = @"C:\Program Files (x86)\YourNameHere\0.0.3 - Alpha\Emulators\Dolphin-x64\Dolphin.exe";
            Process.Start(Dolphin);

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string ePSXe = @"C:\Program Files (x86)\YourNameHere\0.0.3 - Alpha\Emulators\ePSXe\ePSXe.exe";
            Process.Start(ePSXe);
        }
    }
}
